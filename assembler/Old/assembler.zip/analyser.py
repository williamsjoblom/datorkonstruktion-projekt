from parser import *

class mode(Enum):
    NOTSET = 0
    IMMEDIATE = 1
    ABSOLUTE = 2
    ZP_ABSOLUTE = 3
    INDIRECT = 4
    INDEXED_INDI = 5
    INDI_INDEXED = 6

class CodeLine():
    cmd = []               # Tokens that will represent one line in memory. LIST
    lin_err = 0            # Error tokens in list tokens? INT
    adr_mode = mode.NOTSET # Mode Enum
    latest = TokenType.NONE
    passed = True         # Passed test?

    def __init__ (self, cmd = [], lin_err = 0, adr_mode = mode.NOTSET,  passed = True, latest = TokenType.NONE):
        self.cmd = cmd
        self.lin_err = lin_err
        self.adr_mode = adr_mode
        self.passed = passed
        self.latest = latest

    def printerror(self):
        print("error at line ", self.lin_err)
        for token in self.cmd:
            token.printself()

    def printmore(self):
        for token in self.cmd:
            token.printself()

    # What tokens are allowed to show up next?
    # W00t W00t!!!
    def isValidNext(self, type):
        #print (self.latest, type)

        if ((self.latest == TokenType.NONE) and
        (type == TokenType.OPCODE) or
        (type == TokenType.BRANCH)):
            return True

        elif self.latest == TokenType.BRANCH and type == TokenType.LABEL:
            return True

        elif self.latest == TokenType.LABEL and type == TokenType.END:
            return True

        elif (self.latest == TokenType.OPCODE and
        ((type == TokenType.HTAG) or
        (type == TokenType.DOLLAR) or
        (type == TokenType.LPAREN))):
            return True

        elif self.latest == TokenType.DOLLAR and type == TokenType.HEXA:
            return True

        elif (self.latest == TokenType.HTAG and
        ((type == TokenType.DECI) or
        (type == TokenType.DOLLAR))):
            return True

        elif self.latest == TokenType.LPAREN and type == TokenType.DOLLAR:
            return True

        elif (self.latest == TokenType.HEXA and
        ((type == TokenType.COMMA) or
        (type == TokenType.RPAREN) or
        (type == TokenType.END))):
            return True

        elif self.latest == TokenType.DECI and type == TokenType.END:
            return True

        elif self.latest == TokenType.COMMA and type == TokenType.WORD:
            return True

        elif (self.latest == TokenType.WORD and
        ((type == TokenType.RPAREN) or
        (type == TokenType.END))):
            return True

        elif (self.latest == TokenType.RPAREN and (type == TokenType.END or
        type == TokenType.COMMA)):
            return True
        return False

    def setLatest(self, type):
        self.latest = type

    def getLatest(self):
        return self.latest_token

    def addToken(self, token):
        self.cmd.append(token)

def analyse(tokens, codeList):
    codeLine = CodeLine()
    for token in tokens:

        if not codeLine.passed:
            codeLine.printerror()
            return

        if token.type == TokenType.END:
            print ("radbrytning")
            codeList.append(codeLine)
            codeLine = CodeLine()
        else:
            codeLine.passed = codeLine.passed and codeLine.isValidNext(token.getType())
            codeLine.addToken(token)
            codeLine.setLatest(token.getType())
            #bool1 = codeLine.passed
            #bool2 = codeLine.isValidNext(token.getType())
            #print (bool1, " ", bool2)


def main():
    codeList = []
    tokens = lex("asm2")
    parse(tokens)
    analyse(tokens, codeList)

    for code in codeList:
        code.printmore()
        print ("-----------")


if __name__=="__main__":
    main()
